#import "ABKInAppMessageHTMLFullViewController.h"

/*!
 * Custom implementation for the zip-based HTML IAM type
 */
@implementation ABKInAppMessageHTMLFullViewController

- (BOOL)automaticBodyClicksEnabled {
  return YES;
}

@end
