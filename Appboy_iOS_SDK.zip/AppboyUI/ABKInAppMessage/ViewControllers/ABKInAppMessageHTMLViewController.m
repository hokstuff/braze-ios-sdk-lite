#import "ABKInAppMessageHTMLViewController.h"

/*!
 * Custom implementation for the file-based HTML IAM type
 */
@implementation ABKInAppMessageHTMLViewController

@end
